import React, { useState, useEffect, useRef } from 'react';
import { removeBackground } from "@imgly/background-removal";
import { Controls } from './components/Controls';
import { TextSettings, ProcessState, FONTS } from './types';
import { generateSmartCaption } from './services/geminiService';
import { AlertCircle, Loader2 } from 'lucide-react';

export default function App() {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [foregroundSrc, setForegroundSrc] = useState<string | null>(null);
  const [status, setStatus] = useState<ProcessState>(ProcessState.IDLE);
  const [isGeneratingCaption, setIsGeneratingCaption] = useState(false);
  
  const [settings, setSettings] = useState<TextSettings>({
    text: 'FUTURE',
    fontFamily: FONTS[1].family, // Anton default
    fontSize: 150,
    color: '#ffffff',
    opacity: 1,
    letterSpacing: 0,
    yOffset: 50,
    xOffset: 50,
    shadowBlur: 0,
    shadowColor: '#000000',
  });

  const canvasRef = useRef<HTMLCanvasElement>(null);

  const updateSettings = (key: keyof TextSettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setImageSrc(url);
    setForegroundSrc(null); // Reset foreground
    setStatus(ProcessState.PROCESSING);

    try {
      // Step 1: Remove background to get foreground mask
      // Note: @imgly/background-removal downloads models on first run.
      // We rely on standard config.
      const blob = await removeBackground(file);
      const foregroundUrl = URL.createObjectURL(blob);
      setForegroundSrc(foregroundUrl);
      setStatus(ProcessState.SUCCESS);
    } catch (error) {
      console.error("Background removal failed:", error);
      setStatus(ProcessState.ERROR);
      // Fallback: We still show the image, but the "text behind" effect won't work perfectly
      // In a real app, we might fallback to a simpler mode or retry.
    }
  };

  const handleSmartCaption = async () => {
    if (!imageSrc) return;
    setIsGeneratingCaption(true);
    
    try {
      // Need base64 for Gemini
      const response = await fetch(imageSrc);
      const blob = await response.blob();
      const reader = new FileReader();
      
      reader.onloadend = async () => {
        try {
          const base64 = reader.result as string;
          const caption = await generateSmartCaption(base64);
          updateSettings('text', caption.toUpperCase());
        } catch (err) {
            console.error(err);
        } finally {
            setIsGeneratingCaption(false);
        }
      };
      reader.readAsDataURL(blob);
    } catch (error) {
      console.error("Failed to generate caption", error);
      setIsGeneratingCaption(false);
    }
  };

  const drawCanvas = async (hiddenCanvas: HTMLCanvasElement, exportMode = false) => {
     if (!imageSrc) return;
     
     const ctx = hiddenCanvas.getContext('2d');
     if (!ctx) return;

     // Load images
     const loadImg = (src: string) => new Promise<HTMLImageElement>((resolve, reject) => {
         const img = new Image();
         img.crossOrigin = "anonymous";
         img.onload = () => resolve(img);
         img.onerror = reject;
         img.src = src;
     });

     try {
         const bgImg = await loadImg(imageSrc);
         
         // Set canvas size to match image original size for high quality export
         // Or display size for preview? Better to use original size for drawing logic
         hiddenCanvas.width = bgImg.naturalWidth;
         hiddenCanvas.height = bgImg.naturalHeight;

         // 1. Draw Background
         ctx.drawImage(bgImg, 0, 0);

         // 2. Draw Text
         ctx.save();
         ctx.font = `bold ${settings.fontSize * (hiddenCanvas.width / 1000)}px ${settings.fontFamily}`; // Scale font relative to image width
         ctx.fillStyle = settings.color;
         ctx.globalAlpha = settings.opacity;
         ctx.textAlign = 'center';
         ctx.textBaseline = 'middle';
         
         if (settings.shadowBlur > 0) {
             ctx.shadowColor = settings.shadowColor;
             ctx.shadowBlur = settings.shadowBlur;
         }

         const xPos = (settings.xOffset / 100) * hiddenCanvas.width;
         const yPos = (settings.yOffset / 100) * hiddenCanvas.height;
         
         ctx.fillText(settings.text, xPos, yPos);
         ctx.restore();

         // 3. Draw Foreground (if available)
         if (foregroundSrc && status === ProcessState.SUCCESS) {
             const fgImg = await loadImg(foregroundSrc);
             ctx.drawImage(fgImg, 0, 0, hiddenCanvas.width, hiddenCanvas.height);
         }
         
         return hiddenCanvas;

     } catch (e) {
         console.error("Drawing error", e);
     }
  };

  const handleDownload = async () => {
      if(!imageSrc) return;
      const canvas = document.createElement('canvas');
      await drawCanvas(canvas, true);
      
      const link = document.createElement('a');
      link.download = 'text-behind-image.png';
      link.href = canvas.toDataURL('image/png', 1.0);
      link.click();
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-black overflow-hidden">
      
      {/* Sidebar Controls */}
      <Controls 
        settings={settings}
        updateSettings={updateSettings}
        onGenerateCaption={handleSmartCaption}
        isGeneratingCaption={isGeneratingCaption}
        onUpload={handleImageUpload}
        onDownload={handleDownload}
        isProcessing={status === ProcessState.PROCESSING}
        hasImage={!!imageSrc}
      />

      {/* Main Preview Area */}
      <main className="flex-1 relative flex items-center justify-center bg-[#18181b] p-4 lg:p-12 overflow-hidden">
        
        {/* Pattern Background */}
        <div className="absolute inset-0 opacity-5 pointer-events-none" 
            style={{ 
                backgroundImage: 'radial-gradient(#4f4f4f 1px, transparent 1px)', 
                backgroundSize: '24px 24px' 
            }}
        ></div>

        {!imageSrc ? (
          <div className="text-center space-y-4 max-w-md animate-fade-in-up">
            <h2 className="text-4xl font-bold text-gray-700 select-none">Preview Area</h2>
            <p className="text-gray-500">
               Upload an image from the sidebar to begin. <br/>
               Our AI will automatically process the layers.
            </p>
          </div>
        ) : (
          <div className="relative w-full max-w-4xl h-full flex items-center justify-center animate-fade-in">
             {/* 
                We use HTML/CSS for preview instead of canvas for better performance during dragging/typing.
                However, for "Text Behind", the stacking order is key.
             */}
             <div className="relative shadow-2xl rounded-sm overflow-hidden" style={{ maxHeight: '85vh' }}>
                
                {/* 1. Base Image */}
                <img 
                    src={imageSrc} 
                    alt="Background" 
                    className="max-h-[85vh] w-auto object-contain relative z-0 block"
                />

                {/* 2. Text Layer - Positioned absolutely relative to the container */}
                <div 
                    className="absolute inset-0 z-10 overflow-hidden pointer-events-none flex items-center justify-center"
                >
                    <div 
                        style={{
                            fontFamily: settings.fontFamily,
                            fontSize: `${settings.fontSize * 0.8}px`, // Slight adjustment for screen preview
                            color: settings.color,
                            opacity: settings.opacity,
                            textShadow: settings.shadowBlur > 0 ? `0 0 ${settings.shadowBlur}px ${settings.shadowColor}` : 'none',
                            position: 'absolute',
                            left: `${settings.xOffset}%`,
                            top: `${settings.yOffset}%`,
                            transform: 'translate(-50%, -50%)',
                            whiteSpace: 'nowrap',
                            // Responsive scaling for preview: roughly estimate based on container
                        }}
                        className="font-bold leading-none select-none transition-transform duration-75"
                    >
                        {settings.text}
                    </div>
                </div>

                {/* 3. Foreground Cutout (The Magic Layer) */}
                {foregroundSrc && status === ProcessState.SUCCESS && (
                    <img 
                        src={foregroundSrc} 
                        alt="Foreground" 
                        className="absolute inset-0 w-full h-full object-contain z-20 pointer-events-none"
                    />
                )}
                
                {/* Loading / Error States Overlay */}
                {status === ProcessState.PROCESSING && (
                    <div className="absolute inset-0 bg-black/60 z-50 flex items-center justify-center backdrop-blur-sm">
                        <div className="flex flex-col items-center gap-3">
                            <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                            <span className="text-white font-medium">Extracting Subject...</span>
                        </div>
                    </div>
                )}
                
                {status === ProcessState.ERROR && (
                    <div className="absolute top-4 right-4 bg-red-900/90 text-white px-4 py-2 rounded-lg z-50 flex items-center gap-2 text-sm backdrop-blur-md border border-red-700">
                        <AlertCircle className="w-4 h-4" />
                        <span>Background removal failed. Text will appear on top.</span>
                    </div>
                )}

             </div>
          </div>
        )}
      </main>
    </div>
  );
}