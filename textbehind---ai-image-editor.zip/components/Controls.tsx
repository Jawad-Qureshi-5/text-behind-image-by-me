import React from 'react';
import { Wand2, Type, Move, Palette, Download, Upload } from 'lucide-react';
import { TextSettings, FONTS } from '../types';
import { Button } from './Button';

interface ControlsProps {
  settings: TextSettings;
  updateSettings: (key: keyof TextSettings, value: any) => void;
  onGenerateCaption: () => void;
  isGeneratingCaption: boolean;
  onUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onDownload: () => void;
  isProcessing: boolean;
  hasImage: boolean;
}

export const Controls: React.FC<ControlsProps> = ({
  settings,
  updateSettings,
  onGenerateCaption,
  isGeneratingCaption,
  onUpload,
  onDownload,
  isProcessing,
  hasImage
}) => {
  return (
    <div className="w-full lg:w-96 bg-gray-900 border-l border-gray-800 h-screen overflow-y-auto p-6 flex flex-col gap-8 shadow-2xl z-30">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          TextBehind
        </h1>
        <p className="text-gray-400 text-sm mt-1">Create depth with AI</p>
      </div>

      {/* Upload Section */}
      <div className="p-6 border-2 border-dashed border-gray-700 rounded-xl bg-gray-900/50 hover:border-blue-500/50 transition-colors text-center relative group">
        <input
          type="file"
          accept="image/*"
          onChange={onUpload}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
        />
        <div className="flex flex-col items-center gap-2">
          <div className="p-3 bg-gray-800 rounded-full group-hover:bg-gray-700 transition-colors">
            <Upload className="w-6 h-6 text-blue-400" />
          </div>
          <span className="text-sm font-medium text-gray-300">Click to upload image</span>
        </div>
      </div>

      {hasImage && (
        <div className="flex flex-col gap-6 animate-fade-in">
          
          {/* Smart Caption */}
          <div className="flex gap-2">
            <input
              type="text"
              value={settings.text}
              onChange={(e) => updateSettings('text', e.target.value)}
              className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all font-medium"
              placeholder="Enter text..."
            />
            <Button 
              onClick={onGenerateCaption} 
              isLoading={isGeneratingCaption}
              variant="secondary"
              title="Generate Smart Caption"
              className="px-3"
            >
              <Wand2 className="w-4 h-4 text-purple-400" />
            </Button>
          </div>

          {/* Fonts */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-gray-400">
              <Type className="w-4 h-4" />
              <span>Typography</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {FONTS.map((font) => (
                <button
                  key={font.name}
                  onClick={() => updateSettings('fontFamily', font.family)}
                  className={`px-3 py-2 text-sm rounded-md transition-all border ${
                    settings.fontFamily === font.family
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-750'
                  }`}
                  style={{ fontFamily: font.family }}
                >
                  {font.name}
                </button>
              ))}
            </div>
          </div>

          {/* Position & Size */}
          <div className="space-y-4">
             <div className="flex items-center gap-2 text-sm font-semibold text-gray-400">
              <Move className="w-4 h-4" />
              <span>Layout & Size</span>
            </div>
            
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-gray-500">
                <span>Size</span>
                <span>{settings.fontSize}px</span>
              </div>
              <input
                type="range"
                min="20"
                max="400"
                value={settings.fontSize}
                onChange={(e) => updateSettings('fontSize', Number(e.target.value))}
                className="w-full accent-blue-500 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            <div className="space-y-1">
               <div className="flex justify-between text-xs text-gray-500">
                <span>Vertical Position</span>
                <span>{settings.yOffset}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.yOffset}
                onChange={(e) => updateSettings('yOffset', Number(e.target.value))}
                className="w-full accent-blue-500 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
            </div>

             <div className="space-y-1">
               <div className="flex justify-between text-xs text-gray-500">
                <span>Horizontal Position</span>
                <span>{settings.xOffset}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.xOffset}
                onChange={(e) => updateSettings('xOffset', Number(e.target.value))}
                className="w-full accent-blue-500 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>

          {/* Style */}
           <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-semibold text-gray-400">
              <Palette className="w-4 h-4" />
              <span>Style</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Color</span>
              <div className="flex items-center gap-2">
                 <input
                  type="color"
                  value={settings.color}
                  onChange={(e) => updateSettings('color', e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer border-0 bg-transparent p-0"
                />
                <span className="text-xs text-gray-500 uppercase">{settings.color}</span>
              </div>
            </div>

            <div className="space-y-1">
               <div className="flex justify-between text-xs text-gray-500">
                <span>Opacity</span>
                <span>{Math.round(settings.opacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={settings.opacity}
                onChange={(e) => updateSettings('opacity', Number(e.target.value))}
                className="w-full accent-blue-500 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
            </div>
             <div className="space-y-1">
               <div className="flex justify-between text-xs text-gray-500">
                <span>Shadow Blur</span>
                <span>{settings.shadowBlur}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.shadowBlur}
                onChange={(e) => updateSettings('shadowBlur', Number(e.target.value))}
                className="w-full accent-blue-500 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-gray-800">
            <Button
              onClick={onDownload}
              className="w-full"
              size="lg"
              icon={<Download className="w-5 h-5" />}
              disabled={isProcessing}
            >
              {isProcessing ? 'Processing Image...' : 'Download Result'}
            </Button>
          </div>

        </div>
      )}
      
      {!hasImage && (
        <div className="mt-10 p-4 bg-blue-900/20 border border-blue-900/50 rounded-lg">
          <p className="text-blue-200 text-sm text-center">
            Upload an image to start editing. The AI will automatically detect the subject and place your text behind it.
          </p>
        </div>
      )}
    </div>
  );
};