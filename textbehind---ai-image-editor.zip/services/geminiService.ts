import { GoogleGenAI } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateSmartCaption = async (base64Image: string): Promise<string> => {
  try {
    const ai = getClient();
    // Remove header if present (e.g., "data:image/jpeg;base64,")
    const cleanBase64 = base64Image.split(',')[1] || base64Image;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType: 'image/jpeg', // Assuming jpeg for simplicity, though standard works with png too
            },
          },
          {
            text: "Analyze this image and generate a single, short, impactful word or short phrase (max 3 words) suitable for a magazine cover title behind the subject (e.g., 'SUMMER', 'VOGUE', 'WILD', 'URBAN'). Return ONLY the text, nothing else, no quotes.",
          },
        ],
      },
    });

    const text = response.text;
    return text ? text.trim() : "EPIC";
  } catch (error) {
    console.error("Gemini Caption Error:", error);
    throw error;
  }
};