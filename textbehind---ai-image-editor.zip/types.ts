export interface TextSettings {
  text: string;
  fontFamily: string;
  fontSize: number;
  color: string;
  opacity: number;
  letterSpacing: number;
  yOffset: number; // Vertical position (0-100%)
  xOffset: number; // Horizontal position (0-100%)
  shadowBlur: number;
  shadowColor: string;
}

export enum ProcessState {
  IDLE = 'IDLE',
  PROCESSING = 'PROCESSING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export const FONTS = [
  { name: 'Inter', family: 'Inter, sans-serif' },
  { name: 'Anton', family: 'Anton, sans-serif' },
  { name: 'Bebas Neue', family: 'Bebas Neue, sans-serif' },
  { name: 'Oswald', family: 'Oswald, sans-serif' },
  { name: 'Playfair', family: 'Playfair Display, serif' },
  { name: 'Lobster', family: 'Lobster, cursive' },
  { name: 'Pacifico', family: 'Pacifico, cursive' },
  { name: 'Roboto', family: 'Roboto, sans-serif' },
];